from pydantic import BaseModel

# Basic User Information
class BasicUserInfo(BaseModel):
    """
    A wrapper `BaseModel` class that contains the very basic of user information.
    Information that is usally expected in signing in and creating users

    Attrubutes
    -----------
    * username : `str`\\
        The username of the user
    * password: `str` \\
        The password of the user
    """
    username: str
    password: str


class SecurityDetails(BasicUserInfo):
    disabled : bool = False


class CreateUserRequest(SecurityDetails):
    email: str
    name: str
    surname: str
