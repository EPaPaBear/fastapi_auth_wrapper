from fastapi_simplified.models.generics.auditable import * 

class User(Auditable):

    """
    A base user class that other specific user types can derive from.
    It has basic user information and is used predominantly for security.

    Attributes
    -----------
    * id : `Integer`\\
        The row id

    * username : `String`\\
        The username of the user
        
    * password : `String`\\
        The password of the user
    
    Methods
    --------
    None for now
    """

    __abstract__ = True

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(255), unique=True, index=True)
    password = Column(String(255))