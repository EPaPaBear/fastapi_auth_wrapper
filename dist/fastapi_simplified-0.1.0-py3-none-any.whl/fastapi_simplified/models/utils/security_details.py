from fastapi_simplified.models.generics.generic_user import *


class SecurityDetails(User):
    """
    A base class for defining common security information.\\
    Since SQLAlchemy does not support undefined/unverified pydantic models, our best bet is to
    use `Mixin` classes here by inheriting the Pydantic definition from the `User` model.

    Attributes
    ----------
    * disabled : `boolean`\\
    The Disability status of the user

    Methods
    -------
    None for now
    """

    __abstract__ = True

    disabled = Column(Boolean)
