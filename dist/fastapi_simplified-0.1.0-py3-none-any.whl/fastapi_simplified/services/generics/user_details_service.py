import abc

class UserDetailService(metaclass=abc.ABCMeta):
    @classmethod
    def __subclasshook__(cls, subclass):
        return (hasattr(subclass, 'get_by_username') and 
                callable(subclass.load_data_source) or
                NotImplemented)

    @abc.abstractmethod
    def get_by_username_password(self, username:str, password:str):
        ''''Get a user by user name and verify password'''
        raise NotImplementedError

    @abc.abstractmethod
    def get_by_username(self, username:str):
        ''' Get a user by user name '''
        raise NotImplementedError