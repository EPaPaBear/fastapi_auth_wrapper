from datetime import datetime, timedelta, timezone
from jose import jwt, JWTError
from dotenv import load_dotenv
import os

# Load environment variables
load_dotenv(r"resources/.env")

secret_key = os.getenv("JWT_SECRET_KEY")
algorithm = os.getenv("JWT_ALGORITHM")
expiry = float(os.getenv("JWT_EXPIRES_IN"))


# Create docs for them
def create_access_token(data : dict) -> str:
    to_encode = data.copy()
    expire = timedelta(minutes=expiry) + datetime.now(timezone.utc)
    to_encode.update({"expires": expire.isoformat()})
    encoded_jwt = jwt.encode(to_encode, secret_key, algorithm=algorithm)
    return encoded_jwt


def get_claim(token:str, key:str) -> str:
    payload = jwt.decode(token, secret_key, algorithms=[algorithm])
    claim : str = payload.get(key)
    if claim is not None:
        return claim

