import abc

class UserDetailsRepository(metaclass=abc.ABCMeta):
    """
    In terms of security implementation, user-entity-related repositories must extend this class
    and define `find_by_username` method.
    """
    @classmethod
    def __subclasshook__(cls, subclass):
        return (hasattr(subclass, 'find_by_username') and 
                callable(subclass.find_by_username) or
                NotImplemented)

    @abc.abstractmethod
    def find_by_username(self, username:str):
        '''Call to database to find username or email or custom field for authentication'''
        raise NotImplementedError